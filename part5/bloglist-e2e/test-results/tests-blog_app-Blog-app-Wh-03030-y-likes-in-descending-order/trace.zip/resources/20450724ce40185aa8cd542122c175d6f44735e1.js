import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3814b24e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3814b24e"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1788434414564";
import BlogForm from "/src/components/BlogForm.jsx";
import LoginForm from "/src/components/loginForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import Notification from "/src/components/Notification.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({ message: null, type: null });
  const blogFormRef = useRef(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const notify = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification({ message: null, type: null });
    }, 5e3);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      notify(`Welcome ${user2.name || user2.username}`);
    } catch (exception) {
      notify("wrong username or password", "error");
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    blogService.setToken(null);
    setUser(null);
  };
  const addBlog = async (blogObject) => {
    try {
      blogFormRef.current?.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat({ ...returnedBlog, user }));
      notify(`a new blog ${returnedBlog.title} by ${returnedBlog.author} added`);
    } catch (exception) {
      console.error("Create error:", exception.response?.data || exception.message);
      notify("failed to create blog", "error");
    }
  };
  const handleLike = async (id, blogObject) => {
    try {
      const returnedBlog = await blogService.update(id, blogObject);
      setBlogs(
        blogs.map((b) => {
          const currentId = b.id || b._id;
          return currentId === id ? { ...returnedBlog, user: b.user || returnedBlog.user } : b;
        })
      );
    } catch (exception) {
      notify("error updating likes", "error");
    }
  };
  const handleDelete = async (id) => {
    try {
      await blogService.remove(id);
      setBlogs(blogs.filter((b) => (b.id || b._id) !== id));
      notify("blog post deleted successfully");
    } catch (exception) {
      console.error("Delete error details:", exception.response?.data || exception.message);
      notify("failed to delete blog post", "error");
    }
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "log in to application" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        LoginForm,
        {
          handleLogin,
          username,
          password,
          setUsername,
          setPassword
        },
        void 0,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 123,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 120,
      columnNumber: 7
    }, this);
  }
  const sortedBlogs = [...blogs].sort((a, b) => b.likes - a.likes);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 138,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 139,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name || user.username,
      " logged in",
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 142,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 140,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 146,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    sortedBlogs.map(
      (blog) => /* @__PURE__ */ jsxDEV(
        Blog,
        {
          blog,
          updateLikes: handleLike,
          deleteBlog: handleDelete,
          currentUser: user
        },
        blog.id || blog._id,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 150,
          columnNumber: 7
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 137,
    columnNumber: 5
  }, this);
};
_s(App, "j7ygYSD9PSJ6B4Maovd9CbXXgDg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJHUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxVQUFVQyxXQUFXLElBQUlmLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0IsTUFBTUMsT0FBTyxJQUFJbkIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ29CLGNBQWNDLGVBQWUsSUFBSXJCLFNBQVMsRUFBRXNCLFNBQVMsTUFBTUMsTUFBTSxLQUFLLENBQUM7QUFFOUUsUUFBTUMsY0FBY3RCLE9BQU8sSUFBSTtBQUUvQkQsWUFBVSxNQUFNO0FBQ2RPLGdCQUFZaUIsT0FBTyxFQUFFQyxLQUFLLENBQUNkLFdBQVVDLFNBQVNELE1BQUssQ0FBQztBQUFBLEVBQ3RELEdBQUcsRUFBRTtBQUVMWCxZQUFVLE1BQU07QUFDZCxVQUFNMEIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVQsUUFBT2EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1IsY0FBUUQsS0FBSTtBQUNaVixrQkFBWXlCLFNBQVNmLE1BQUtnQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLFNBQVNBLENBQUNiLFNBQVNDLE9BQU8sY0FBYztBQUM1Q0Ysb0JBQWdCLEVBQUVDLFNBQVNDLEtBQUssQ0FBQztBQUNqQ2EsZUFBVyxNQUFNO0FBQ2ZmLHNCQUFnQixFQUFFQyxTQUFTLE1BQU1DLE1BQU0sS0FBSyxDQUFDO0FBQUEsSUFDL0MsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFFBQU1jLGNBQWMsT0FBT0MsVUFBVTtBQUNuQ0EsVUFBTUMsZUFBZTtBQUNyQixRQUFJO0FBQ0YsWUFBTXJCLFFBQU8sTUFBTVQsYUFBYStCLE1BQU0sRUFBRTFCLFVBQVVFLFNBQVMsQ0FBQztBQUM1RFksYUFBT0MsYUFBYVksUUFBUSxxQkFBcUJWLEtBQUtXLFVBQVV4QixLQUFJLENBQUM7QUFDckVWLGtCQUFZeUIsU0FBU2YsTUFBS2dCLEtBQUs7QUFDL0JmLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2RrQixhQUFPLFdBQVdqQixNQUFLeUIsUUFBUXpCLE1BQUtKLFFBQVEsRUFBRTtBQUFBLElBQ2hELFNBQVM4QixXQUFXO0FBQ2xCVCxhQUFPLDhCQUE4QixPQUFPO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTVUsZUFBZUEsTUFBTTtBQUN6QmpCLFdBQU9DLGFBQWFpQixXQUFXLG1CQUFtQjtBQUNsRHRDLGdCQUFZeUIsU0FBUyxJQUFJO0FBQ3pCZCxZQUFRLElBQUk7QUFBQSxFQUNkO0FBRUEsUUFBTTRCLFVBQVUsT0FBT0MsZUFBZTtBQUNwQyxRQUFJO0FBQ0Z4QixrQkFBWXlCLFNBQVNDLGlCQUFpQjtBQUN0QyxZQUFNQyxlQUFlLE1BQU0zQyxZQUFZNEMsT0FBT0osVUFBVTtBQUN4RG5DLGVBQVNELE1BQU15QyxPQUFPLEVBQUUsR0FBR0YsY0FBY2pDLEtBQVcsQ0FBQyxDQUFDO0FBQ3REaUIsYUFBTyxjQUFjZ0IsYUFBYUcsS0FBSyxPQUFPSCxhQUFhSSxNQUFNLFFBQVE7QUFBQSxJQUMzRSxTQUFTWCxXQUFXO0FBQ2xCWSxjQUFRQyxNQUFNLGlCQUFpQmIsVUFBVWMsVUFBVUMsUUFBUWYsVUFBVXRCLE9BQU87QUFDNUVhLGFBQU8seUJBQXlCLE9BQU87QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsYUFBYSxPQUFPQyxJQUFJYixlQUFlO0FBQzNDLFFBQUk7QUFDRixZQUFNRyxlQUFlLE1BQU0zQyxZQUFZc0QsT0FBT0QsSUFBSWIsVUFBVTtBQUM1RG5DO0FBQUFBLFFBQ0VELE1BQU1tRCxJQUFJLENBQUNDLE1BQU07QUFDZixnQkFBTUMsWUFBWUQsRUFBRUgsTUFBTUcsRUFBRUU7QUFDNUIsaUJBQU9ELGNBQWNKLEtBQ2pCLEVBQUUsR0FBR1YsY0FBY2pDLE1BQU04QyxFQUFFOUMsUUFBUWlDLGFBQWFqQyxLQUFLLElBQ3JEOEM7QUFBQUEsUUFDTixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3BCLFdBQVc7QUFDbEJULGFBQU8sd0JBQXdCLE9BQU87QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0MsZUFBZSxPQUFPTixPQUFPO0FBQ2pDLFFBQUk7QUFDRixZQUFNckQsWUFBWTRELE9BQU9QLEVBQUU7QUFDM0JoRCxlQUFTRCxNQUFNeUQsT0FBTyxDQUFDTCxPQUFPQSxFQUFFSCxNQUFNRyxFQUFFRSxTQUFTTCxFQUFFLENBQUM7QUFDcEQxQixhQUFPLGdDQUFnQztBQUFBLElBQ3pDLFNBQVNTLFdBQVc7QUFDbEJZLGNBQVFDLE1BQU0seUJBQXlCYixVQUFVYyxVQUFVQyxRQUFRZixVQUFVdEIsT0FBTztBQUNwRmEsYUFBTyw4QkFBOEIsT0FBTztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLE1BQUlqQixTQUFTLE1BQU07QUFDakIsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsZ0JBQWEsU0FBU0UsYUFBYUUsU0FBUyxNQUFNRixhQUFhRyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBO0FBQUEsUUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLMkI7QUFBQSxTQVI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxFQUVKO0FBRUEsUUFBTStDLGNBQWMsQ0FBQyxHQUFHMUQsS0FBSyxFQUFFMkQsS0FBSyxDQUFDQyxHQUFHUixNQUFNQSxFQUFFUyxRQUFRRCxFQUFFQyxLQUFLO0FBRS9ELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxnQkFBYSxTQUFTckQsYUFBYUUsU0FBUyxNQUFNRixhQUFhRyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFFO0FBQUEsSUFDckUsdUJBQUMsT0FDRUw7QUFBQUEsV0FBS3lCLFFBQVF6QixLQUFLSjtBQUFBQSxNQUFTO0FBQUEsTUFBVztBQUFBLE1BQ3ZDLHVCQUFDLFlBQU8sU0FBUytCLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLGFBQVUsYUFBWSxtQkFBa0IsS0FBS3JCLGFBQzVDLGlDQUFDLFlBQVMsWUFBWXVCLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQ3VCLFlBQVlQO0FBQUFBLE1BQUksQ0FBQ1csU0FDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDO0FBQUEsVUFDQSxhQUFhZDtBQUFBQSxVQUNiLFlBQVlPO0FBQUFBLFVBQ1osYUFBYWpEO0FBQUFBO0FBQUFBLFFBSlJ3RCxLQUFLYixNQUFNYSxLQUFLUjtBQUFBQSxRQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS29CO0FBQUEsSUFFckI7QUFBQSxPQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ3ZELEdBbklLRCxLQUFHO0FBQUFpRSxLQUFIakU7QUFxSU4sZUFBZUE7QUFBRyxJQUFBaUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsIkJsb2dGb3JtIiwiTG9naW5Gb3JtIiwiVG9nZ2xhYmxlIiwiTm90aWZpY2F0aW9uIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJibG9nRm9ybVJlZiIsImdldEFsbCIsInRoZW4iLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwibm90aWZ5Iiwic2V0VGltZW91dCIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsIm5hbWUiLCJleGNlcHRpb24iLCJoYW5kbGVMb2dvdXQiLCJyZW1vdmVJdGVtIiwiYWRkQmxvZyIsImJsb2dPYmplY3QiLCJjdXJyZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsInJldHVybmVkQmxvZyIsImNyZWF0ZSIsImNvbmNhdCIsInRpdGxlIiwiYXV0aG9yIiwiY29uc29sZSIsImVycm9yIiwicmVzcG9uc2UiLCJkYXRhIiwiaGFuZGxlTGlrZSIsImlkIiwidXBkYXRlIiwibWFwIiwiYiIsImN1cnJlbnRJZCIsIl9pZCIsImhhbmRsZURlbGV0ZSIsInJlbW92ZSIsImZpbHRlciIsInNvcnRlZEJsb2dzIiwic29ydCIsImEiLCJsaWtlcyIsImJsb2ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcclxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcclxuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvbG9naW5Gb3JtJ1xyXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXHJcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcclxuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXHJcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcclxuXHJcbmNvbnN0IEFwcCA9ICgpID0+IHtcclxuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxyXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZSh7IG1lc3NhZ2U6IG51bGwsIHR5cGU6IG51bGwgfSlcclxuXHJcbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYobnVsbClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oKGJsb2dzKSA9PiBzZXRCbG9ncyhibG9ncykpXHJcbiAgfSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxyXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxyXG4gICAgICBzZXRVc2VyKHVzZXIpXHJcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXHJcbiAgICB9XHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG5vdGlmeSA9IChtZXNzYWdlLCB0eXBlID0gJ3N1Y2Nlc3MnKSA9PiB7XHJcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlLCB0eXBlIH0pXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogbnVsbCwgdHlwZTogbnVsbCB9KVxyXG4gICAgfSwgNTAwMClcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHsgdXNlcm5hbWUsIHBhc3N3b3JkIH0pXHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcclxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBzZXRVc2VybmFtZSgnJylcclxuICAgICAgc2V0UGFzc3dvcmQoJycpXHJcbiAgICAgIG5vdGlmeShgV2VsY29tZSAke3VzZXIubmFtZSB8fCB1c2VyLnVzZXJuYW1lfWApXHJcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcclxuICAgICAgbm90aWZ5KCd3cm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XHJcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJylcclxuICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKG51bGwpXHJcbiAgICBzZXRVc2VyKG51bGwpXHJcbiAgfVxyXG5cclxuICBjb25zdCBhZGRCbG9nID0gYXN5bmMgKGJsb2dPYmplY3QpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQ/LnRvZ2dsZVZpc2liaWxpdHkoKVxyXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHsgLi4ucmV0dXJuZWRCbG9nLCB1c2VyOiB1c2VyIH0pKVxyXG4gICAgICBub3RpZnkoYGEgbmV3IGJsb2cgJHtyZXR1cm5lZEJsb2cudGl0bGV9IGJ5ICR7cmV0dXJuZWRCbG9nLmF1dGhvcn0gYWRkZWRgKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0NyZWF0ZSBlcnJvcjonLCBleGNlcHRpb24ucmVzcG9uc2U/LmRhdGEgfHwgZXhjZXB0aW9uLm1lc3NhZ2UpXHJcbiAgICAgIG5vdGlmeSgnZmFpbGVkIHRvIGNyZWF0ZSBibG9nJywgJ2Vycm9yJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoaWQsIGJsb2dPYmplY3QpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShpZCwgYmxvZ09iamVjdClcclxuICAgICAgc2V0QmxvZ3MoXHJcbiAgICAgICAgYmxvZ3MubWFwKChiKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBjdXJyZW50SWQgPSBiLmlkIHx8IGIuX2lkXHJcbiAgICAgICAgICByZXR1cm4gY3VycmVudElkID09PSBpZFxyXG4gICAgICAgICAgICA/IHsgLi4ucmV0dXJuZWRCbG9nLCB1c2VyOiBiLnVzZXIgfHwgcmV0dXJuZWRCbG9nLnVzZXIgfVxyXG4gICAgICAgICAgICA6IGJcclxuICAgICAgICB9KVxyXG4gICAgICApXHJcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcclxuICAgICAgbm90aWZ5KCdlcnJvciB1cGRhdGluZyBsaWtlcycsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnJlbW92ZShpZClcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKChiKSA9PiAoYi5pZCB8fCBiLl9pZCkgIT09IGlkKSlcclxuICAgICAgbm90aWZ5KCdibG9nIHBvc3QgZGVsZXRlZCBzdWNjZXNzZnVsbHknKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0RlbGV0ZSBlcnJvciBkZXRhaWxzOicsIGV4Y2VwdGlvbi5yZXNwb25zZT8uZGF0YSB8fCBleGNlcHRpb24ubWVzc2FnZSlcclxuICAgICAgbm90aWZ5KCdmYWlsZWQgdG8gZGVsZXRlIGJsb2cgcG9zdCcsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpZiAodXNlciA9PT0gbnVsbCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8aDI+bG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cclxuICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuICAgICAgICA8TG9naW5Gb3JtXHJcbiAgICAgICAgICBoYW5kbGVMb2dpbj17aGFuZGxlTG9naW59XHJcbiAgICAgICAgICB1c2VybmFtZT17dXNlcm5hbWV9XHJcbiAgICAgICAgICBwYXNzd29yZD17cGFzc3dvcmR9XHJcbiAgICAgICAgICBzZXRVc2VybmFtZT17c2V0VXNlcm5hbWV9XHJcbiAgICAgICAgICBzZXRQYXNzd29yZD17c2V0UGFzc3dvcmR9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjb25zdCBzb3J0ZWRCbG9ncyA9IFsuLi5ibG9nc10uc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+YmxvZ3M8L2gyPlxyXG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuICAgICAgPHA+XHJcbiAgICAgICAge3VzZXIubmFtZSB8fCB1c2VyLnVzZXJuYW1lfSBsb2dnZWQgaW57JyAnfVxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cclxuICAgICAgPC9wPlxyXG5cclxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cImNyZWF0ZSBuZXcgYmxvZ1wiIHJlZj17YmxvZ0Zvcm1SZWZ9PlxyXG4gICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxyXG4gICAgICA8L1RvZ2dsYWJsZT5cclxuXHJcbiAgICAgIHtzb3J0ZWRCbG9ncy5tYXAoKGJsb2cpID0+IChcclxuICAgICAgICA8QmxvZ1xyXG4gICAgICAgICAga2V5PXtibG9nLmlkIHx8IGJsb2cuX2lkfVxyXG4gICAgICAgICAgYmxvZz17YmxvZ31cclxuICAgICAgICAgIHVwZGF0ZUxpa2VzPXtoYW5kbGVMaWtlfVxyXG4gICAgICAgICAgZGVsZXRlQmxvZz17aGFuZGxlRGVsZXRlfVxyXG4gICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9