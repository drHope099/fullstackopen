import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogDetail.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const BlogDetail = ({ blog, handleLike, handleDelete, currentUser }) => {
  if (!blog) return null;
  const onLike = () => {
    const updatedBlog = {
      user: blog.user?.id || blog.user,
      likes: (blog.likes || 0) + 1,
      author: blog.author,
      title: blog.title,
      url: blog.url
    };
    handleLike(blog.id || blog._id, updatedBlog);
  };
  const isCreator = currentUser && blog.user && (blog.user.username === currentUser.username || blog.user === currentUser.id || blog.user.id === currentUser.id);
  return /* @__PURE__ */ jsxDEV("div", { className: "blog-detail", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: [
      blog.title,
      " ",
      blog.author
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("a", { href: blog.url, children: blog.url }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 44,
      columnNumber: 12
    }, this) }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.likes || 0,
      " likes",
      " ",
      currentUser && /* @__PURE__ */ jsxDEV("button", { onClick: onLike, children: "like" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
        lineNumber: 47,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "added by ",
      blog.user?.name || blog.user?.username || "unknown"
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    isCreator && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(blog.id || blog._id), children: "remove" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
};
_c = BlogDetail;
export default BlogDetail;
var _c;
$RefreshReg$(_c, "BlogDetail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/BlogDetail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkJOLE1BQU1BLGFBQWFBLENBQUMsRUFBRUMsTUFBTUMsWUFBWUMsY0FBY0MsWUFBWSxNQUFNO0FBQ3RFLE1BQUksQ0FBQ0gsS0FBTSxRQUFPO0FBRWxCLFFBQU1JLFNBQVNBLE1BQU07QUFDbkIsVUFBTUMsY0FBYztBQUFBLE1BQ2xCQyxNQUFNTixLQUFLTSxNQUFNQyxNQUFNUCxLQUFLTTtBQUFBQSxNQUM1QkUsUUFBUVIsS0FBS1EsU0FBUyxLQUFLO0FBQUEsTUFDM0JDLFFBQVFULEtBQUtTO0FBQUFBLE1BQ2JDLE9BQU9WLEtBQUtVO0FBQUFBLE1BQ1pDLEtBQUtYLEtBQUtXO0FBQUFBLElBQ1o7QUFDQVYsZUFBV0QsS0FBS08sTUFBTVAsS0FBS1ksS0FBS1AsV0FBVztBQUFBLEVBQzdDO0FBRUEsUUFBTVEsWUFDSlYsZUFDQUgsS0FBS00sU0FDSk4sS0FBS00sS0FBS1EsYUFBYVgsWUFBWVcsWUFDbENkLEtBQUtNLFNBQVNILFlBQVlJLE1BQzFCUCxLQUFLTSxLQUFLQyxPQUFPSixZQUFZSTtBQUVqQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsMkJBQUMsUUFBSVA7QUFBQUEsV0FBS1U7QUFBQUEsTUFBTTtBQUFBLE1BQUVWLEtBQUtTO0FBQUFBLFNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxJQUM5Qix1QkFBQyxTQUFJLGlDQUFDLE9BQUUsTUFBTVQsS0FBS1csS0FBTVgsZUFBS1csT0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QixLQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNDO0FBQUEsSUFDdEMsdUJBQUMsU0FDRVg7QUFBQUEsV0FBS1EsU0FBUztBQUFBLE1BQUU7QUFBQSxNQUFPO0FBQUEsTUFDdkJMLGVBQWUsdUJBQUMsWUFBTyxTQUFTQyxRQUFRLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsU0FGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxNQUFVSixLQUFLTSxNQUFNUyxRQUFRZixLQUFLTSxNQUFNUSxZQUFZO0FBQUEsU0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRTtBQUFBLElBQ2xFRCxhQUNDLHVCQUFDLFlBQU8sU0FBUyxNQUFNWCxhQUFhRixLQUFLTyxNQUFNUCxLQUFLWSxHQUFHLEdBQUcsc0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0U7QUFBQSxPQVRwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDSSxLQW5DS2pCO0FBcUNOLGVBQWVBO0FBQVUsSUFBQWlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCbG9nRGV0YWlsIiwiYmxvZyIsImhhbmRsZUxpa2UiLCJoYW5kbGVEZWxldGUiLCJjdXJyZW50VXNlciIsIm9uTGlrZSIsInVwZGF0ZWRCbG9nIiwidXNlciIsImlkIiwibGlrZXMiLCJhdXRob3IiLCJ0aXRsZSIsInVybCIsIl9pZCIsImlzQ3JlYXRvciIsInVzZXJuYW1lIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2dEZXRhaWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEJsb2dEZXRhaWwgPSAoeyBibG9nLCBoYW5kbGVMaWtlLCBoYW5kbGVEZWxldGUsIGN1cnJlbnRVc2VyIH0pID0+IHtcclxuICBpZiAoIWJsb2cpIHJldHVybiBudWxsXHJcblxyXG4gIGNvbnN0IG9uTGlrZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0ge1xyXG4gICAgICB1c2VyOiBibG9nLnVzZXI/LmlkIHx8IGJsb2cudXNlcixcclxuICAgICAgbGlrZXM6IChibG9nLmxpa2VzIHx8IDApICsgMSxcclxuICAgICAgYXV0aG9yOiBibG9nLmF1dGhvcixcclxuICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXHJcbiAgICAgIHVybDogYmxvZy51cmwsXHJcbiAgICB9XHJcbiAgICBoYW5kbGVMaWtlKGJsb2cuaWQgfHwgYmxvZy5faWQsIHVwZGF0ZWRCbG9nKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaXNDcmVhdG9yID1cclxuICAgIGN1cnJlbnRVc2VyICYmXHJcbiAgICBibG9nLnVzZXIgJiZcclxuICAgIChibG9nLnVzZXIudXNlcm5hbWUgPT09IGN1cnJlbnRVc2VyLnVzZXJuYW1lIHx8XHJcbiAgICAgIGJsb2cudXNlciA9PT0gY3VycmVudFVzZXIuaWQgfHxcclxuICAgICAgYmxvZy51c2VyLmlkID09PSBjdXJyZW50VXNlci5pZClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1kZXRhaWxcIj5cclxuICAgICAgPGgyPntibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9PC9oMj5cclxuICAgICAgPGRpdj48YSBocmVmPXtibG9nLnVybH0+e2Jsb2cudXJsfTwvYT48L2Rpdj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICB7YmxvZy5saWtlcyB8fCAwfSBsaWtlc3snICd9XHJcbiAgICAgICAge2N1cnJlbnRVc2VyICYmIDxidXR0b24gb25DbGljaz17b25MaWtlfT5saWtlPC9idXR0b24+fVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdj5hZGRlZCBieSB7YmxvZy51c2VyPy5uYW1lIHx8IGJsb2cudXNlcj8udXNlcm5hbWUgfHwgJ3Vua25vd24nfTwvZGl2PlxyXG4gICAgICB7aXNDcmVhdG9yICYmIChcclxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShibG9nLmlkIHx8IGJsb2cuX2lkKX0+cmVtb3ZlPC9idXR0b24+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJsb2dEZXRhaWwiXSwiZmlsZSI6IkM6L1VzZXJzL01JQ1JPU1BBQ0UvRGVza3RvcC9zb2Z0bmV0L2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0RldGFpbC5qc3gifQ==