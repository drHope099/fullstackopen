import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4f52f818"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Routes, Route, Link, useNavigate, useMatch } from "/node_modules/.vite/deps/react-router-dom.js?v=f518dd54";
import Blog from "/src/components/Blog.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import LoginForm from "/src/components/loginForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import Notification from "/src/components/Notification.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import BlogList from "/src/components/Bloglist.jsx";
import BlogDetail from "/src/components/BlogDetail.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({ message: null, type: null });
  const navigate = useNavigate();
  const blogFormRef = useRef(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const notify = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification({ message: null, type: null });
    }, 5e3);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      notify(`Welcome ${user2.name || user2.username}`);
      navigate("/");
    } catch (exception) {
      notify("wrong username or password", "error");
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    blogService.setToken(null);
    setUser(null);
    navigate("/");
  };
  const addBlog = async (blogObject) => {
    try {
      blogFormRef.current?.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat({ ...returnedBlog, user }));
      notify(`a new blog ${returnedBlog.title} by ${returnedBlog.author} added`);
    } catch (exception) {
      console.error("Create error:", exception.response?.data || exception.message);
      notify("failed to create blog", "error");
    }
  };
  const handleLike = async (id, blogObject) => {
    try {
      const returnedBlog = await blogService.update(id, blogObject);
      setBlogs(
        blogs.map((b) => {
          const currentId = b.id || b._id;
          return currentId === id ? { ...returnedBlog, user: b.user || returnedBlog.user } : b;
        })
      );
    } catch (exception) {
      notify("error updating likes", "error");
    }
  };
  const handleDelete = async (id) => {
    try {
      await blogService.remove(id);
      setBlogs(blogs.filter((b) => (b.id || b._id) !== id));
      notify("blog post deleted successfully");
      navigate("/");
    } catch (exception) {
      console.error("Delete error details:", exception.response?.data || exception.message);
      notify("failed to delete blog post", "error");
    }
  };
  const match = useMatch("/blogs/:id");
  const matchedBlog = match ? blogs.find((b) => (b.id || b._id) === match.params.id) : null;
  const navStyle = {
    padding: 10,
    backgroundColor: "#f4f4f4",
    marginBottom: 15,
    borderBottom: "1px solid #ccc"
  };
  const padding = {
    padding: 5
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("nav", { style: navStyle, children: [
      /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/", children: "blogs" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 144,
        columnNumber: 9
      }, this),
      user ? /* @__PURE__ */ jsxDEV("span", { children: [
        /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/create", children: "create new" }, void 0, false, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 147,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("em", { children: [
          user.name || user.username,
          " logged in"
        ] }, void 0, true, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 149,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 146,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(Link, { style: padding, to: "/login", children: "login" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 152,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "blog app" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 157,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(BlogList, { blogs }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 160,
        columnNumber: 34
      }, this) }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 160,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/login",
          element: user ? /* @__PURE__ */ jsxDEV(Navigate, { replace: true, to: "/" }, void 0, false, {
            fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
            lineNumber: 165,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(
            LoginForm,
            {
              handleLogin,
              username,
              password,
              setUsername,
              setPassword
            },
            void 0,
            false,
            {
              fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
              lineNumber: 167,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 161,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/create",
          element: user ? /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
            fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
            lineNumber: 181,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Navigate, { replace: true, to: "/login" }, void 0, false, {
            fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
            lineNumber: 183,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 177,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/blogs/:id",
          element: /* @__PURE__ */ jsxDEV(
            BlogDetail,
            {
              blog: matchedBlog,
              handleLike,
              handleDelete,
              currentUser: user
            },
            void 0,
            false,
            {
              fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
              lineNumber: 190,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 187,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 159,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 142,
    columnNumber: 5
  }, this);
};
_s(App, "rvo43ugRI49CDfIANPAyQgRKajY=", false, function() {
  return [useNavigate, useMatch];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEhROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVIUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLFNBQVNDLFFBQVFDLE9BQU9DLE1BQU1DLGFBQWFDLGdCQUFnQjtBQUMzRCxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixVQUFVQyxXQUFXLElBQUl0QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDdUIsVUFBVUMsV0FBVyxJQUFJeEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3lCLE1BQU1DLE9BQU8sSUFBSTFCLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUk1QixTQUFTLEVBQUU2QixTQUFTLE1BQU1DLE1BQU0sS0FBSyxDQUFDO0FBQzlFLFFBQU1DLFdBQVd6QixZQUFZO0FBQzdCLFFBQU0wQixjQUFjOUIsT0FBTyxJQUFJO0FBRS9CRCxZQUFVLE1BQU07QUFDZFksZ0JBQVlvQixPQUFPLEVBQUVDLEtBQUssQ0FBQ2YsV0FBVUMsU0FBU0QsTUFBSyxDQUFDO0FBQUEsRUFDdEQsR0FBRyxFQUFFO0FBRUxsQixZQUFVLE1BQU07QUFDZCxVQUFNa0MsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVYsUUFBT2MsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1QsY0FBUUQsS0FBSTtBQUNaWixrQkFBWTRCLFNBQVNoQixNQUFLaUIsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxTQUFTQSxDQUFDZCxTQUFTQyxPQUFPLGNBQWM7QUFDNUNGLG9CQUFnQixFQUFFQyxTQUFTQyxLQUFLLENBQUM7QUFDakNjLGVBQVcsTUFBTTtBQUNmaEIsc0JBQWdCLEVBQUVDLFNBQVMsTUFBTUMsTUFBTSxLQUFLLENBQUM7QUFBQSxJQUMvQyxHQUFHLEdBQUk7QUFBQSxFQUNUO0FBRUEsUUFBTWUsY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBQ3JCLFFBQUk7QUFDRixZQUFNdEIsUUFBTyxNQUFNWCxhQUFha0MsTUFBTSxFQUFFM0IsVUFBVUUsU0FBUyxDQUFDO0FBQzVEYSxhQUFPQyxhQUFhWSxRQUFRLHFCQUFxQlYsS0FBS1csVUFBVXpCLEtBQUksQ0FBQztBQUNyRVosa0JBQVk0QixTQUFTaEIsTUFBS2lCLEtBQUs7QUFDL0JoQixjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUNkbUIsYUFBTyxXQUFXbEIsTUFBSzBCLFFBQVExQixNQUFLSixRQUFRLEVBQUU7QUFDOUNVLGVBQVMsR0FBRztBQUFBLElBQ2QsU0FBU3FCLFdBQVc7QUFDbEJULGFBQU8sOEJBQThCLE9BQU87QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNVSxlQUFlQSxNQUFNO0FBQ3pCakIsV0FBT0MsYUFBYWlCLFdBQVcsbUJBQW1CO0FBQ2xEekMsZ0JBQVk0QixTQUFTLElBQUk7QUFDekJmLFlBQVEsSUFBSTtBQUNaSyxhQUFTLEdBQUc7QUFBQSxFQUNkO0FBRUEsUUFBTXdCLFVBQVUsT0FBT0MsZUFBZTtBQUNwQyxRQUFJO0FBQ0Z4QixrQkFBWXlCLFNBQVNDLGlCQUFpQjtBQUN0QyxZQUFNQyxlQUFlLE1BQU05QyxZQUFZK0MsT0FBT0osVUFBVTtBQUN4RHBDLGVBQVNELE1BQU0wQyxPQUFPLEVBQUUsR0FBR0YsY0FBY2xDLEtBQVcsQ0FBQyxDQUFDO0FBQ3REa0IsYUFBTyxjQUFjZ0IsYUFBYUcsS0FBSyxPQUFPSCxhQUFhSSxNQUFNLFFBQVE7QUFBQSxJQUMzRSxTQUFTWCxXQUFXO0FBQ2xCWSxjQUFRQyxNQUFNLGlCQUFpQmIsVUFBVWMsVUFBVUMsUUFBUWYsVUFBVXZCLE9BQU87QUFDNUVjLGFBQU8seUJBQXlCLE9BQU87QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsYUFBYSxPQUFPQyxJQUFJYixlQUFlO0FBQzNDLFFBQUk7QUFDRixZQUFNRyxlQUFlLE1BQU05QyxZQUFZeUQsT0FBT0QsSUFBSWIsVUFBVTtBQUM1RHBDO0FBQUFBLFFBQ0VELE1BQU1vRCxJQUFJLENBQUNDLE1BQU07QUFDZixnQkFBTUMsWUFBWUQsRUFBRUgsTUFBTUcsRUFBRUU7QUFDNUIsaUJBQU9ELGNBQWNKLEtBQ2pCLEVBQUUsR0FBR1YsY0FBY2xDLE1BQU0rQyxFQUFFL0MsUUFBUWtDLGFBQWFsQyxLQUFLLElBQ3JEK0M7QUFBQUEsUUFDTixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3BCLFdBQVc7QUFDbEJULGFBQU8sd0JBQXdCLE9BQU87QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0MsZUFBZSxPQUFPTixPQUFPO0FBQ2pDLFFBQUk7QUFDRixZQUFNeEQsWUFBWStELE9BQU9QLEVBQUU7QUFDM0JqRCxlQUFTRCxNQUFNMEQsT0FBTyxDQUFDTCxPQUFPQSxFQUFFSCxNQUFNRyxFQUFFRSxTQUFTTCxFQUFFLENBQUM7QUFDcEQxQixhQUFPLGdDQUFnQztBQUN2Q1osZUFBUyxHQUFHO0FBQUEsSUFDZCxTQUFTcUIsV0FBVztBQUNsQlksY0FBUUMsTUFBTSx5QkFBeUJiLFVBQVVjLFVBQVVDLFFBQVFmLFVBQVV2QixPQUFPO0FBQ3BGYyxhQUFPLDhCQUE4QixPQUFPO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBR0EsUUFBTW1DLFFBQVF2RSxTQUFTLFlBQVk7QUFDbkMsUUFBTXdFLGNBQWNELFFBQ2pCM0QsTUFBTTZELEtBQUssQ0FBQ1IsT0FBT0EsRUFBRUgsTUFBTUcsRUFBRUUsU0FBU0ksTUFBTUcsT0FBT1osRUFBRSxJQUNwRDtBQUVGLFFBQU1hLFdBQVc7QUFBQSxJQUNqQkMsU0FBUztBQUFBLElBQ1RDLGlCQUFpQjtBQUFBLElBQ2pCQyxjQUFjO0FBQUEsSUFDZEMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUgsVUFBVTtBQUFBLElBQ2RBLFNBQVM7QUFBQSxFQUNYO0FBRUQsU0FDRyx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxPQUFPRCxVQUNWO0FBQUEsNkJBQUMsUUFBSyxPQUFPQyxTQUFTLElBQUcsS0FBSSxxQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2pDMUQsT0FDQyx1QkFBQyxVQUNDO0FBQUEsK0JBQUMsUUFBSyxPQUFPMEQsU0FBUyxJQUFHLFdBQVUsMEJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFJMUQ7QUFBQUEsZUFBSzBCLFFBQVExQixLQUFLSjtBQUFBQSxVQUFTO0FBQUEsYUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQU07QUFBQSxRQUNoRCx1QkFBQyxZQUFPLFNBQVNnQyxjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsV0FIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBRUEsdUJBQUMsUUFBSyxPQUFPOEIsU0FBUyxJQUFHLFVBQVMscUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxTQVQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxnQkFBYSxTQUFTeEQsYUFBYUUsU0FBUyxNQUFNRixhQUFhRyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFFO0FBQUEsSUFFckUsdUJBQUMsVUFDQztBQUFBLDZCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBUyxTQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUIsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLE1BQ3BEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUNFTCxPQUNFLHVCQUFDLFlBQVMsU0FBTyxNQUFDLElBQUcsT0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsSUFFeEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLMkI7QUFBQTtBQUFBLFFBWGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWNHO0FBQUEsTUFFSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FDRUEsT0FDRSx1QkFBQyxZQUFTLFlBQVk4QixXQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QixJQUU5Qix1QkFBQyxZQUFTLFNBQU8sTUFBQyxJQUFHLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUE7QUFBQSxRQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRRztBQUFBLE1BRUg7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU13QjtBQUFBQSxjQUNOO0FBQUEsY0FDQTtBQUFBLGNBQ0EsYUFBYXREO0FBQUFBO0FBQUFBLFlBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSW9CO0FBQUE7QUFBQSxRQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTRztBQUFBLFNBckNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxPQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeURBO0FBRUo7QUFBQ1AsR0F6S0tELEtBQUc7QUFBQSxVQU1VWCxhQXVGSEMsUUFBUTtBQUFBO0FBQUFnRixLQTdGbEJ0RTtBQTJLTixlQUFlQTtBQUFHLElBQUFzRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJSb3V0ZXMiLCJSb3V0ZSIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsInVzZU1hdGNoIiwiQmxvZyIsIkJsb2dGb3JtIiwiTG9naW5Gb3JtIiwiVG9nZ2xhYmxlIiwiTm90aWZpY2F0aW9uIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJCbG9nTGlzdCIsIkJsb2dEZXRhaWwiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJuYXZpZ2F0ZSIsImJsb2dGb3JtUmVmIiwiZ2V0QWxsIiwidGhlbiIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJub3RpZnkiLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwibmFtZSIsImV4Y2VwdGlvbiIsImhhbmRsZUxvZ291dCIsInJlbW92ZUl0ZW0iLCJhZGRCbG9nIiwiYmxvZ09iamVjdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmV0dXJuZWRCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwidGl0bGUiLCJhdXRob3IiLCJjb25zb2xlIiwiZXJyb3IiLCJyZXNwb25zZSIsImRhdGEiLCJoYW5kbGVMaWtlIiwiaWQiLCJ1cGRhdGUiLCJtYXAiLCJiIiwiY3VycmVudElkIiwiX2lkIiwiaGFuZGxlRGVsZXRlIiwicmVtb3ZlIiwiZmlsdGVyIiwibWF0Y2giLCJtYXRjaGVkQmxvZyIsImZpbmQiLCJwYXJhbXMiLCJuYXZTdHlsZSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kQ29sb3IiLCJtYXJnaW5Cb3R0b20iLCJib3JkZXJCb3R0b20iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBSb3V0ZXMsIFJvdXRlLCBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlTWF0Y2ggfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcclxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcclxuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvbG9naW5Gb3JtJ1xyXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXHJcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcclxuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXHJcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcclxuaW1wb3J0IEJsb2dMaXN0IGZyb20gJy4vY29tcG9uZW50cy9CbG9nbGlzdCdcclxuaW1wb3J0IEJsb2dEZXRhaWwgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dEZXRhaWwnXHJcblxyXG5jb25zdCBBcHAgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcclxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUoeyBtZXNzYWdlOiBudWxsLCB0eXBlOiBudWxsIH0pXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYobnVsbClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oKGJsb2dzKSA9PiBzZXRCbG9ncyhibG9ncykpXHJcbiAgfSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxyXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxyXG4gICAgICBzZXRVc2VyKHVzZXIpXHJcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXHJcbiAgICB9XHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IG5vdGlmeSA9IChtZXNzYWdlLCB0eXBlID0gJ3N1Y2Nlc3MnKSA9PiB7XHJcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlLCB0eXBlIH0pXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogbnVsbCwgdHlwZTogbnVsbCB9KVxyXG4gICAgfSwgNTAwMClcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHsgdXNlcm5hbWUsIHBhc3N3b3JkIH0pXHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcclxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBzZXRVc2VybmFtZSgnJylcclxuICAgICAgc2V0UGFzc3dvcmQoJycpXHJcbiAgICAgIG5vdGlmeShgV2VsY29tZSAke3VzZXIubmFtZSB8fCB1c2VyLnVzZXJuYW1lfWApXHJcbiAgICAgIG5hdmlnYXRlKCcvJylcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBub3RpZnkoJ3dyb25nIHVzZXJuYW1lIG9yIHBhc3N3b3JkJywgJ2Vycm9yJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxyXG4gICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obnVsbClcclxuICAgIHNldFVzZXIobnVsbClcclxuICAgIG5hdmlnYXRlKCcvJylcclxuICB9XHJcblxyXG4gIGNvbnN0IGFkZEJsb2cgPSBhc3luYyAoYmxvZ09iamVjdCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYmxvZ0Zvcm1SZWYuY3VycmVudD8udG9nZ2xlVmlzaWJpbGl0eSgpXHJcbiAgICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZShibG9nT2JqZWN0KVxyXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQoeyAuLi5yZXR1cm5lZEJsb2csIHVzZXI6IHVzZXIgfSkpXHJcbiAgICAgIG5vdGlmeShgYSBuZXcgYmxvZyAke3JldHVybmVkQmxvZy50aXRsZX0gYnkgJHtyZXR1cm5lZEJsb2cuYXV0aG9yfSBhZGRlZGApXHJcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcclxuICAgICAgY29uc29sZS5lcnJvcignQ3JlYXRlIGVycm9yOicsIGV4Y2VwdGlvbi5yZXNwb25zZT8uZGF0YSB8fCBleGNlcHRpb24ubWVzc2FnZSlcclxuICAgICAgbm90aWZ5KCdmYWlsZWQgdG8gY3JlYXRlIGJsb2cnLCAnZXJyb3InKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTGlrZSA9IGFzeW5jIChpZCwgYmxvZ09iamVjdCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKGlkLCBibG9nT2JqZWN0KVxyXG4gICAgICBzZXRCbG9ncyhcclxuICAgICAgICBibG9ncy5tYXAoKGIpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGN1cnJlbnRJZCA9IGIuaWQgfHwgYi5faWRcclxuICAgICAgICAgIHJldHVybiBjdXJyZW50SWQgPT09IGlkXHJcbiAgICAgICAgICAgID8geyAuLi5yZXR1cm5lZEJsb2csIHVzZXI6IGIudXNlciB8fCByZXR1cm5lZEJsb2cudXNlciB9XHJcbiAgICAgICAgICAgIDogYlxyXG4gICAgICAgIH0pXHJcbiAgICAgIClcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBub3RpZnkoJ2Vycm9yIHVwZGF0aW5nIGxpa2VzJywgJ2Vycm9yJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UucmVtb3ZlKGlkKVxyXG4gICAgICBzZXRCbG9ncyhibG9ncy5maWx0ZXIoKGIpID0+IChiLmlkIHx8IGIuX2lkKSAhPT0gaWQpKVxyXG4gICAgICBub3RpZnkoJ2Jsb2cgcG9zdCBkZWxldGVkIHN1Y2Nlc3NmdWxseScpXHJcbiAgICAgIG5hdmlnYXRlKCcvJylcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdEZWxldGUgZXJyb3IgZGV0YWlsczonLCBleGNlcHRpb24ucmVzcG9uc2U/LmRhdGEgfHwgZXhjZXB0aW9uLm1lc3NhZ2UpXHJcbiAgICAgIG5vdGlmeSgnZmFpbGVkIHRvIGRlbGV0ZSBibG9nIHBvc3QnLCAnZXJyb3InKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy9FeHRyYWN0IHBhcmFtZXRlcml6ZWQgYmxvZyBpZCBmcm9tIC9ibG9ncy86aWQgcm91dGVcclxuICBjb25zdCBtYXRjaCA9IHVzZU1hdGNoKCcvYmxvZ3MvOmlkJylcclxuICBjb25zdCBtYXRjaGVkQmxvZyA9IG1hdGNoXHJcbiAgID8gYmxvZ3MuZmluZCgoYikgPT4gKGIuaWQgfHwgYi5faWQpID09PSBtYXRjaC5wYXJhbXMuaWQpXHJcbiAgICA6IG51bGxcclxuXHJcbiAgICBjb25zdCBuYXZTdHlsZSA9IHtcclxuICAgIHBhZGRpbmc6IDEwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiAnI2Y0ZjRmNCcsXHJcbiAgICBtYXJnaW5Cb3R0b206IDE1LFxyXG4gICAgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkICNjY2MnLFxyXG4gIH1cclxuXHJcbiAgY29uc3QgcGFkZGluZyA9IHtcclxuICAgIHBhZGRpbmc6IDUsXHJcbiAgfVxyXG5cclxuIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bmF2IHN0eWxlPXtuYXZTdHlsZX0+XHJcbiAgICAgICAgPExpbmsgc3R5bGU9e3BhZGRpbmd9IHRvPVwiL1wiPmJsb2dzPC9MaW5rPlxyXG4gICAgICAgIHt1c2VyID8gKFxyXG4gICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgIDxMaW5rIHN0eWxlPXtwYWRkaW5nfSB0bz1cIi9jcmVhdGVcIj5jcmVhdGUgbmV3PC9MaW5rPlxyXG4gICAgICAgICAgICA8ZW0+e3VzZXIubmFtZSB8fCB1c2VyLnVzZXJuYW1lfSBsb2dnZWQgaW48L2VtPnsnICd9XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPExpbmsgc3R5bGU9e3BhZGRpbmd9IHRvPVwiL2xvZ2luXCI+bG9naW48L0xpbms+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9uYXY+XHJcblxyXG4gICAgICA8aDI+YmxvZyBhcHA8L2gyPlxyXG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuXHJcbiAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEJsb2dMaXN0IGJsb2dzPXtibG9nc30gLz59IC8+XHJcbiAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICBwYXRoPVwiL2xvZ2luXCJcclxuICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICB1c2VyID8gKFxyXG4gICAgICAgICAgICAgIDxOYXZpZ2F0ZSByZXBsYWNlIHRvPVwiL1wiIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPExvZ2luRm9ybVxyXG4gICAgICAgICAgICAgICAgaGFuZGxlTG9naW49e2hhbmRsZUxvZ2lufVxyXG4gICAgICAgICAgICAgICAgdXNlcm5hbWU9e3VzZXJuYW1lfVxyXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgc2V0VXNlcm5hbWU9e3NldFVzZXJuYW1lfVxyXG4gICAgICAgICAgICAgICAgc2V0UGFzc3dvcmQ9e3NldFBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgcGF0aD1cIi9jcmVhdGVcIlxyXG4gICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgIHVzZXIgPyAoXHJcbiAgICAgICAgICAgICAgPEJsb2dGb3JtIGNyZWF0ZUJsb2c9e2FkZEJsb2d9IC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPE5hdmlnYXRlIHJlcGxhY2UgdG89XCIvbG9naW5cIiAvPlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8Um91dGVcclxuICAgICAgICAgIHBhdGg9XCIvYmxvZ3MvOmlkXCJcclxuICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICA8QmxvZ0RldGFpbFxyXG4gICAgICAgICAgICAgIGJsb2c9e21hdGNoZWRCbG9nfVxyXG4gICAgICAgICAgICAgIGhhbmRsZUxpa2U9e2hhbmRsZUxpa2V9XHJcbiAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlPXtoYW5kbGVEZWxldGV9XHJcbiAgICAgICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9Sb3V0ZXM+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9