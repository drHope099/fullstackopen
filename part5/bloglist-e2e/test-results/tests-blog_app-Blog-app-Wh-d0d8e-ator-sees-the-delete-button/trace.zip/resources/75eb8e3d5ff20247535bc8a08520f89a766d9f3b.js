import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({ message, type }) => {
  if (!message) return null;
  const notificationStyle = {
    color: type === "error" ? "red" : "green",
    background: "lightgrey",
    border: "1px solid",
    borderColor: type === "error" ? "red" : "green",
    padding: "10px",
    margin: "10px 0"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: type === "error" ? "error" : "success", style: notificationStyle, children: message }, void 0, false, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFiSixNQUFNQSxlQUFlQSxDQUFDLEVBQUVDLFNBQVNDLEtBQUssTUFBTTtBQUMxQyxNQUFJLENBQUNELFFBQVMsUUFBTztBQUVyQixRQUFNRSxvQkFBb0I7QUFBQSxJQUN4QkMsT0FBT0YsU0FBUyxVQUFVLFFBQVE7QUFBQSxJQUNsQ0csWUFBWTtBQUFBLElBQ1pDLFFBQVE7QUFBQSxJQUNSQyxhQUFhTCxTQUFTLFVBQVUsUUFBUTtBQUFBLElBQ3hDTSxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLEVBQ1Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBV1AsU0FBUyxVQUFVLFVBQVUsV0FBVyxPQUFPQyxtQkFDNURGLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNTLEtBakJLVjtBQW1CTixlQUFlQTtBQUFZLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOb3RpZmljYXRpb24iLCJtZXNzYWdlIiwidHlwZSIsIm5vdGlmaWNhdGlvblN0eWxlIiwiY29sb3IiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJwYWRkaW5nIiwibWFyZ2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBOb3RpZmljYXRpb24gPSAoeyBtZXNzYWdlLCB0eXBlIH0pID0+IHtcclxuICBpZiAoIW1lc3NhZ2UpIHJldHVybiBudWxsXHJcblxyXG4gIGNvbnN0IG5vdGlmaWNhdGlvblN0eWxlID0ge1xyXG4gICAgY29sb3I6IHR5cGUgPT09ICdlcnJvcicgPyAncmVkJyA6ICdncmVlbicsXHJcbiAgICBiYWNrZ3JvdW5kOiAnbGlnaHRncmV5JyxcclxuICAgIGJvcmRlcjogJzFweCBzb2xpZCcsXHJcbiAgICBib3JkZXJDb2xvcjogdHlwZSA9PT0gJ2Vycm9yJyA/ICdyZWQnIDogJ2dyZWVuJyxcclxuICAgIHBhZGRpbmc6ICcxMHB4JyxcclxuICAgIG1hcmdpbjogJzEwcHggMCcsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e3R5cGUgPT09ICdlcnJvcicgPyAnZXJyb3InIDogJ3N1Y2Nlc3MnfSBzdHlsZT17bm90aWZpY2F0aW9uU3R5bGV9PlxyXG4gICAgICB7bWVzc2FnZX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uIl0sImZpbGUiOiJDOi9Vc2Vycy9NSUNST1NQQUNFL0Rlc2t0b3Avc29mdG5ldC9mdWxsc3RhY2tvcGVuL3BhcnQ1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gifQ==