import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Bloglist.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f518dd54";
const BlogList = ({ blogs }) => {
  const sortedBlogs = [...blogs].sort((a, b) => (b.likes || 0) - (a.likes || 0));
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  return /* @__PURE__ */ jsxDEV("div", { children: sortedBlogs.map(
    (blog) => /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", children: /* @__PURE__ */ jsxDEV(Link, { to: `/blogs/${blog.id || blog._id}`, children: [
      blog.title,
      " ",
      blog.author
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx",
      lineNumber: 37,
      columnNumber: 11
    }, this) }, blog.id || blog._id, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_c = BlogList;
export default BlogList;
var _c;
$RefreshReg$(_c, "BlogList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Bloglist.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJWLFNBQVNBLFlBQVk7QUFFckIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxNQUFNLE1BQU07QUFDOUIsUUFBTUMsY0FBYyxDQUFDLEdBQUdELEtBQUssRUFBRUUsS0FBSyxDQUFDQyxHQUFHQyxPQUFPQSxFQUFFQyxTQUFTLE1BQU1GLEVBQUVFLFNBQVMsRUFBRTtBQUU3RSxRQUFNQyxZQUFZO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxTQUNFLHVCQUFDLFNBQ0VWLHNCQUFZVztBQUFBQSxJQUFJLENBQUNDLFNBQ2hCLHVCQUFDLFNBQThCLE9BQU9QLFdBQVcsV0FBVSxRQUN6RCxpQ0FBQyxRQUFLLElBQUksVUFBVU8sS0FBS0MsTUFBTUQsS0FBS0UsR0FBRyxJQUNwQ0Y7QUFBQUEsV0FBS0c7QUFBQUEsTUFBTTtBQUFBLE1BQUVILEtBQUtJO0FBQUFBLFNBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhRSixLQUFLQyxNQUFNRCxLQUFLRSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ0csS0F0QktuQjtBQXdCTixlQUFlQTtBQUFRLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTGluayIsIkJsb2dMaXN0IiwiYmxvZ3MiLCJzb3J0ZWRCbG9ncyIsInNvcnQiLCJhIiwiYiIsImxpa2VzIiwiYmxvZ1N0eWxlIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0IiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJtYXAiLCJibG9nIiwiaWQiLCJfaWQiLCJ0aXRsZSIsImF1dGhvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2dsaXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuXHJcbmNvbnN0IEJsb2dMaXN0ID0gKHsgYmxvZ3MgfSkgPT4ge1xyXG4gIGNvbnN0IHNvcnRlZEJsb2dzID0gWy4uLmJsb2dzXS5zb3J0KChhLCBiKSA9PiAoYi5saWtlcyB8fCAwKSAtIChhLmxpa2VzIHx8IDApKVxyXG5cclxuICBjb25zdCBibG9nU3R5bGUgPSB7XHJcbiAgICBwYWRkaW5nVG9wOiAxMCxcclxuICAgIHBhZGRpbmdMZWZ0OiAyLFxyXG4gICAgYm9yZGVyOiAnc29saWQnLFxyXG4gICAgYm9yZGVyV2lkdGg6IDEsXHJcbiAgICBtYXJnaW5Cb3R0b206IDUsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAge3NvcnRlZEJsb2dzLm1hcCgoYmxvZykgPT4gKFxyXG4gICAgICAgIDxkaXYga2V5PXtibG9nLmlkIHx8IGJsb2cuX2lkfSBzdHlsZT17YmxvZ1N0eWxlfSBjbGFzc05hbWU9XCJibG9nXCI+XHJcbiAgICAgICAgICA8TGluayB0bz17YC9ibG9ncy8ke2Jsb2cuaWQgfHwgYmxvZy5faWR9YH0+XHJcbiAgICAgICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCbG9nTGlzdCJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nbGlzdC5qc3gifQ==