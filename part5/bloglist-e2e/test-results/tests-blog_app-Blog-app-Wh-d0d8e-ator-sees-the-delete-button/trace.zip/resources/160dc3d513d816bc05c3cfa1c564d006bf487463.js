import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4f52f818"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
const Togglable = (props) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = { display: visible ? "none" : "" };
  const showWhenVisible = { display: visible ? "" : "none" };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(props.ref, () => {
    return { toggleVisibility };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 39,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "Cancel" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
};
_s(Togglable, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c = Togglable;
export default Togglable;
var _c;
$RefreshReg$(_c, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Togglable.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CUixTQUFTQSxVQUFVQywyQkFBMkI7QUFFOUMsTUFBTUMsWUFBWUEsQ0FBQ0MsVUFBVTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJTixTQUFTLEtBQUs7QUFFNUMsUUFBTU8sa0JBQWtCLEVBQUVDLFNBQVNILFVBQVUsU0FBUyxHQUFHO0FBQ3pELFFBQU1JLGtCQUFrQixFQUFFRCxTQUFTSCxVQUFVLEtBQUssT0FBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBRUFKLHNCQUFvQkUsTUFBTVEsS0FBSyxNQUFNO0FBQ25DLFdBQU8sRUFBRUQsaUJBQWlCO0FBQUEsRUFDNUIsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0gsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJQLGdCQUFNUyxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPSCxpQkFDVE47QUFBQUEsWUFBTVU7QUFBQUEsTUFDUCx1QkFBQyxZQUFPLFNBQVNILGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ04sR0F6QktGLFdBQVM7QUFBQVksS0FBVFo7QUEyQk4sZUFBZUE7QUFBUyxJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VJbXBlcmF0aXZlSGFuZGxlIiwiVG9nZ2xhYmxlIiwicHJvcHMiLCJfcyIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwiaGlkZVdoZW5WaXNpYmxlIiwiZGlzcGxheSIsInNob3dXaGVuVmlzaWJsZSIsInRvZ2dsZVZpc2liaWxpdHkiLCJyZWYiLCJidXR0b25MYWJlbCIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9nZ2xhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlSW1wZXJhdGl2ZUhhbmRsZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxuY29uc3QgVG9nZ2xhYmxlID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICdub25lJyA6ICcnIH1cclxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XHJcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxyXG4gIH1cclxuXHJcbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShwcm9wcy5yZWYsICgpID0+IHtcclxuICAgIHJldHVybiB7IHRvZ2dsZVZpc2liaWxpdHkgfVxyXG4gIH0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+e3Byb3BzLmJ1dHRvbkxhYmVsfTwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfT5cclxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5DYW5jZWw8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZSJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2dnbGFibGUuanN4In0=