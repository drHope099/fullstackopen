import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/loginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f52f818"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const LoginForm = ({
  handleLogin,
  username,
  password,
  setUsername,
  setPassword
}) => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
  /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: "username", children: "username" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        id: "username",
        type: "text",
        value: username,
        name: "Username",
        onChange: ({ target }) => setUsername(target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
        lineNumber: 30,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
    lineNumber: 28,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: "password", children: "password" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        id: "password",
        type: "password",
        value: password,
        name: "Password",
        onChange: ({ target }) => setPassword(target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
        lineNumber: 41,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
    lineNumber: 50,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx",
  lineNumber: 27,
  columnNumber: 1
}, this);
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/loginForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixNQUFNQSxZQUFZQSxDQUFDO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFDRSx1QkFBQyxVQUFLLFVBQVVKLGFBQ2Q7QUFBQSx5QkFBQyxTQUNDO0FBQUEsMkJBQUMsV0FBTSxTQUFRLFlBQVcsd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxJQUNsQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsTUFBSztBQUFBLFFBQ0wsT0FBT0M7QUFBQUEsUUFDUCxNQUFLO0FBQUEsUUFDTCxVQUFVLENBQUMsRUFBRUksT0FBTyxNQUFNRixZQUFZRSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxNQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLc0Q7QUFBQSxPQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFBQSxFQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxXQUFNLFNBQVEsWUFBVyx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQztBQUFBLElBQ2xDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFHO0FBQUEsUUFDSCxNQUFLO0FBQUEsUUFDTCxPQUFPSjtBQUFBQSxRQUNQLE1BQUs7QUFBQSxRQUNMLFVBQVUsQ0FBQyxFQUFFRyxPQUFPLE1BQU1ELFlBQVlDLE9BQU9DLEtBQUs7QUFBQTtBQUFBLE1BTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtzRDtBQUFBLE9BUHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUFBLEVBRUEsdUJBQUMsWUFBTyxNQUFLLFVBQVMscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkI7QUFBQSxLQXZCN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQXdCQTtBQUNEQyxLQWhDS1I7QUFrQ04sZUFBZUE7QUFBUyxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTG9naW5Gb3JtIiwiaGFuZGxlTG9naW4iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwic2V0VXNlcm5hbWUiLCJzZXRQYXNzd29yZCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBMb2dpbkZvcm0gPSAoe1xyXG4gIGhhbmRsZUxvZ2luLFxyXG4gIHVzZXJuYW1lLFxyXG4gIHBhc3N3b3JkLFxyXG4gIHNldFVzZXJuYW1lLFxyXG4gIHNldFBhc3N3b3JkIFxyXG59KSA9PiAoXHJcbiAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufT5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlcm5hbWVcIj51c2VybmFtZTwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPVwidXNlcm5hbWVcIlxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XHJcbiAgICAgICAgbmFtZT1cIlVzZXJuYW1lXCJcclxuICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+cGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICBuYW1lPVwiUGFzc3dvcmRcIlxyXG4gICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XHJcbiAgPC9mb3JtPlxyXG4pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm0iXSwiZmlsZSI6IkM6L1VzZXJzL01JQ1JPU1BBQ0UvRGVza3RvcC9zb2Z0bmV0L2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvbG9naW5Gb3JtLmpzeCJ9