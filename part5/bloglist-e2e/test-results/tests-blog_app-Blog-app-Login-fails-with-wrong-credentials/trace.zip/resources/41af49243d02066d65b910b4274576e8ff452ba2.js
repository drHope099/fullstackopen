import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3814b24e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({ notification }) => {
  if (!notification || !notification.message) return null;
  const notificationStyle = {
    color: notification.type === "error" ? "red" : "green",
    background: "lightgrey",
    border: "1px solid",
    borderColor: notification.type === "error" ? "red" : "green",
    padding: "10px",
    margin: "10px 0"
  };
  return /* @__PURE__ */ jsxDEV("div", { style: notificationStyle, children: notification.message }, void 0, false, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaVCxNQUFNQSxlQUFlQSxDQUFDLEVBQUVDLGFBQWEsTUFBTTtBQUN6QyxNQUFJLENBQUNBLGdCQUFnQixDQUFDQSxhQUFhQyxRQUFTLFFBQU87QUFFbkQsUUFBTUMsb0JBQW9CO0FBQUEsSUFDeEJDLE9BQU9ILGFBQWFJLFNBQVMsVUFBVSxRQUFRO0FBQUEsSUFDL0NDLFlBQVk7QUFBQSxJQUNaQyxRQUFRO0FBQUEsSUFDUkMsYUFBYVAsYUFBYUksU0FBUyxVQUFVLFFBQVE7QUFBQSxJQUNyREksU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxFQUNWO0FBRUEsU0FBTyx1QkFBQyxTQUFJLE9BQU9QLG1CQUFvQkYsdUJBQWFDLFdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUQ7QUFDOUQ7QUFBQ1MsS0FiS1g7QUFlTixlQUFlQTtBQUFZLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOb3RpZmljYXRpb24iLCJub3RpZmljYXRpb24iLCJtZXNzYWdlIiwibm90aWZpY2F0aW9uU3R5bGUiLCJjb2xvciIsInR5cGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJwYWRkaW5nIiwibWFyZ2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBOb3RpZmljYXRpb24gPSAoeyBub3RpZmljYXRpb24gfSkgPT4ge1xyXG4gIGlmICghbm90aWZpY2F0aW9uIHx8ICFub3RpZmljYXRpb24ubWVzc2FnZSkgcmV0dXJuIG51bGxcclxuXHJcbiAgY29uc3Qgbm90aWZpY2F0aW9uU3R5bGUgPSB7XHJcbiAgICBjb2xvcjogbm90aWZpY2F0aW9uLnR5cGUgPT09ICdlcnJvcicgPyAncmVkJyA6ICdncmVlbicsXHJcbiAgICBiYWNrZ3JvdW5kOiAnbGlnaHRncmV5JyxcclxuICAgIGJvcmRlcjogJzFweCBzb2xpZCcsXHJcbiAgICBib3JkZXJDb2xvcjogbm90aWZpY2F0aW9uLnR5cGUgPT09ICdlcnJvcicgPyAncmVkJyA6ICdncmVlbicsXHJcbiAgICBwYWRkaW5nOiAnMTBweCcsXHJcbiAgICBtYXJnaW46ICcxMHB4IDAnLFxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIDxkaXYgc3R5bGU9e25vdGlmaWNhdGlvblN0eWxlfT57bm90aWZpY2F0aW9uLm1lc3NhZ2V9PC9kaXY+XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbiJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ob3RpZmljYXRpb24uanN4In0=