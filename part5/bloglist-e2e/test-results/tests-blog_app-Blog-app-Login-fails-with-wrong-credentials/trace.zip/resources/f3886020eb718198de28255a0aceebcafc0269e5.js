import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3814b24e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3814b24e"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import Notification from "/src/components/Notification.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({ message: null, type: null });
  const blogFormRef = useRef(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const notify = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification({ message: null, type: null });
    }, 5e3);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      notify(`Welcome ${user2.name || user2.username}`);
    } catch (exception) {
      notify("wrong username or password", "error");
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    blogService.setToken(null);
    setUser(null);
  };
  const addBlog = async (blogObject) => {
    try {
      blogFormRef.current?.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat({ ...returnedBlog, user }));
      notify(`a new blog ${returnedBlog.title} by ${returnedBlog.author} added`);
    } catch (exception) {
      console.error("Create error:", exception.response?.data || exception.message);
      notify("failed to create blog", "error");
    }
  };
  const handleLike = async (id, blogObject) => {
    try {
      const returnedBlog = await blogService.update(id, blogObject);
      setBlogs(
        blogs.map((b) => {
          const currentId = b.id || b._id;
          return currentId === id ? { ...returnedBlog, user: b.user || returnedBlog.user } : b;
        })
      );
    } catch (exception) {
      notify("error updating likes", "error");
    }
  };
  const handleDelete = async (id) => {
    try {
      await blogService.remove(id);
      setBlogs(blogs.filter((b) => (b.id || b._id) !== id));
      notify("blog post deleted successfully");
    } catch (exception) {
      console.error("Delete error details:", exception.response?.data || exception.message);
      notify("failed to delete blog post", "error");
    }
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "username",
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: username,
              onChange: ({ target }) => setUsername(target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
              lineNumber: 126,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "password",
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: password,
              onChange: ({ target }) => setPassword(target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
              lineNumber: 133,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 131,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 139,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 120,
      columnNumber: 7
    }, this);
  }
  const sortedBlogs = [...blogs].sort((a, b) => b.likes - a.likes);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 150,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name || user.username,
      " logged in",
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 153,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 157,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    sortedBlogs.map(
      (blog) => /* @__PURE__ */ jsxDEV(
        Blog,
        {
          blog,
          updateLikes: handleLike,
          deleteBlog: handleDelete,
          currentUser: user
        },
        blog.id || blog._id,
        false,
        {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 161,
          columnNumber: 7
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 148,
    columnNumber: 5
  }, this);
};
_s(App, "j7ygYSD9PSJ6B4Maovd9CbXXgDg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJHUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVosU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ21CLGNBQWNDLGVBQWUsSUFBSXBCLFNBQVMsRUFBRXFCLFNBQVMsTUFBTUMsTUFBTSxLQUFLLENBQUM7QUFFOUUsUUFBTUMsY0FBY3JCLE9BQU8sSUFBSTtBQUUvQkQsWUFBVSxNQUFNO0FBQ2RNLGdCQUFZaUIsT0FBTyxFQUFFQyxLQUFLLENBQUNkLFdBQVVDLFNBQVNELE1BQUssQ0FBQztBQUFBLEVBQ3RELEdBQUcsRUFBRTtBQUVMVixZQUFVLE1BQU07QUFDZCxVQUFNeUIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVQsUUFBT2EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1IsY0FBUUQsS0FBSTtBQUNaVixrQkFBWXlCLFNBQVNmLE1BQUtnQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLFNBQVNBLENBQUNiLFNBQVNDLE9BQU8sY0FBYztBQUM1Q0Ysb0JBQWdCLEVBQUVDLFNBQVNDLEtBQUssQ0FBQztBQUNqQ2EsZUFBVyxNQUFNO0FBQ2ZmLHNCQUFnQixFQUFFQyxTQUFTLE1BQU1DLE1BQU0sS0FBSyxDQUFDO0FBQUEsSUFDL0MsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFFBQU1jLGNBQWMsT0FBT0MsVUFBVTtBQUNuQ0EsVUFBTUMsZUFBZTtBQUNyQixRQUFJO0FBQ0YsWUFBTXJCLFFBQU8sTUFBTVQsYUFBYStCLE1BQU0sRUFBRTFCLFVBQVVFLFNBQVMsQ0FBQztBQUM1RFksYUFBT0MsYUFBYVksUUFBUSxxQkFBcUJWLEtBQUtXLFVBQVV4QixLQUFJLENBQUM7QUFDckVWLGtCQUFZeUIsU0FBU2YsTUFBS2dCLEtBQUs7QUFDL0JmLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2RrQixhQUFPLFdBQVdqQixNQUFLeUIsUUFBUXpCLE1BQUtKLFFBQVEsRUFBRTtBQUFBLElBQ2hELFNBQVM4QixXQUFXO0FBQ2xCVCxhQUFPLDhCQUE4QixPQUFPO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTVUsZUFBZUEsTUFBTTtBQUN6QmpCLFdBQU9DLGFBQWFpQixXQUFXLG1CQUFtQjtBQUNsRHRDLGdCQUFZeUIsU0FBUyxJQUFJO0FBQ3pCZCxZQUFRLElBQUk7QUFBQSxFQUNkO0FBRUEsUUFBTTRCLFVBQVUsT0FBT0MsZUFBZTtBQUNwQyxRQUFJO0FBRUZ4QixrQkFBWXlCLFNBQVNDLGlCQUFpQjtBQUN0QyxZQUFNQyxlQUFlLE1BQU0zQyxZQUFZNEMsT0FBT0osVUFBVTtBQUN4RG5DLGVBQVNELE1BQU15QyxPQUFPLEVBQUUsR0FBR0YsY0FBY2pDLEtBQVcsQ0FBQyxDQUFDO0FBQ3REaUIsYUFBTyxjQUFjZ0IsYUFBYUcsS0FBSyxPQUFPSCxhQUFhSSxNQUFNLFFBQVE7QUFBQSxJQUMzRSxTQUFTWCxXQUFXO0FBQ2xCWSxjQUFRQyxNQUFNLGlCQUFpQmIsVUFBVWMsVUFBVUMsUUFBUWYsVUFBVXRCLE9BQU87QUFDNUVhLGFBQU8seUJBQXlCLE9BQU87QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsYUFBYSxPQUFPQyxJQUFJYixlQUFlO0FBQzNDLFFBQUk7QUFDRixZQUFNRyxlQUFlLE1BQU0zQyxZQUFZc0QsT0FBT0QsSUFBSWIsVUFBVTtBQUM1RG5DO0FBQUFBLFFBQ0VELE1BQU1tRCxJQUFJLENBQUNDLE1BQU07QUFDZixnQkFBTUMsWUFBWUQsRUFBRUgsTUFBTUcsRUFBRUU7QUFDNUIsaUJBQU9ELGNBQWNKLEtBQ2pCLEVBQUUsR0FBR1YsY0FBY2pDLE1BQU04QyxFQUFFOUMsUUFBUWlDLGFBQWFqQyxLQUFLLElBQ3JEOEM7QUFBQUEsUUFDTixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3BCLFdBQVc7QUFDbEJULGFBQU8sd0JBQXdCLE9BQU87QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0MsZUFBZSxPQUFPTixPQUFPO0FBQ2pDLFFBQUk7QUFDRixZQUFNckQsWUFBWTRELE9BQU9QLEVBQUU7QUFDM0JoRCxlQUFTRCxNQUFNeUQsT0FBTyxDQUFDTCxPQUFPQSxFQUFFSCxNQUFNRyxFQUFFRSxTQUFTTCxFQUFFLENBQUM7QUFDcEQxQixhQUFPLGdDQUFnQztBQUFBLElBQ3pDLFNBQVNTLFdBQVc7QUFDbEJZLGNBQVFDLE1BQU0seUJBQXlCYixVQUFVYyxVQUFVQyxRQUFRZixVQUFVdEIsT0FBTztBQUNwRmEsYUFBTyw4QkFBOEIsT0FBTztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLE1BQUlqQixTQUFTLE1BQU07QUFDakIsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsZ0JBQWEsU0FBU0UsYUFBYUUsU0FBUyxNQUFNRixhQUFhRyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsVUFBSyxVQUFVYyxhQUNkO0FBQUEsK0JBQUMsU0FBSTtBQUFBO0FBQUEsVUFFSDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3ZCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDLEVBQUV3RCxPQUFPLE1BQU12RCxZQUFZdUQsT0FBT0MsS0FBSztBQUFBO0FBQUEsWUFGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXNEO0FBQUEsYUFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxVQUVIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPdkQ7QUFBQUEsY0FDUCxVQUFVLENBQUMsRUFBRXNELE9BQU8sTUFBTXJELFlBQVlxRCxPQUFPQyxLQUFLO0FBQUE7QUFBQSxZQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHc0Q7QUFBQSxhQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FoQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsRUFFSjtBQUVBLFFBQU1DLGNBQWMsQ0FBQyxHQUFHNUQsS0FBSyxFQUFFNkQsS0FBSyxDQUFDQyxHQUFHVixNQUFNQSxFQUFFVyxRQUFRRCxFQUFFQyxLQUFLO0FBRS9ELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxnQkFBYSxTQUFTdkQsYUFBYUUsU0FBUyxNQUFNRixhQUFhRyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFFO0FBQUEsSUFDckUsdUJBQUMsT0FDRUw7QUFBQUEsV0FBS3lCLFFBQVF6QixLQUFLSjtBQUFBQSxNQUFTO0FBQUEsTUFBVztBQUFBLE1BQ3ZDLHVCQUFDLFlBQU8sU0FBUytCLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLGFBQVUsYUFBWSxtQkFBa0IsS0FBS3JCLGFBQzVDLGlDQUFDLFlBQVMsWUFBWXVCLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQ3lCLFlBQVlUO0FBQUFBLE1BQUksQ0FBQ2EsU0FDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDO0FBQUEsVUFDQSxhQUFhaEI7QUFBQUEsVUFDYixZQUFZTztBQUFBQSxVQUNaLGFBQWFqRDtBQUFBQTtBQUFBQSxRQUpSMEQsS0FBS2YsTUFBTWUsS0FBS1Y7QUFBQUEsUUFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtvQjtBQUFBLElBRXJCO0FBQUEsT0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQTtBQUVKO0FBQUN2RCxHQS9JS0QsS0FBRztBQUFBbUUsS0FBSG5FO0FBaUpOLGVBQWVBO0FBQUcsSUFBQW1FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkJsb2ciLCJCbG9nRm9ybSIsIlRvZ2dsYWJsZSIsIk5vdGlmaWNhdGlvbiIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJ1c2VyIiwic2V0VXNlciIsIm5vdGlmaWNhdGlvbiIsInNldE5vdGlmaWNhdGlvbiIsIm1lc3NhZ2UiLCJ0eXBlIiwiYmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsIm5vdGlmeSIsInNldFRpbWVvdXQiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJuYW1lIiwiZXhjZXB0aW9uIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImFkZEJsb2ciLCJibG9nT2JqZWN0IiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJyZXR1cm5lZEJsb2ciLCJjcmVhdGUiLCJjb25jYXQiLCJ0aXRsZSIsImF1dGhvciIsImNvbnNvbGUiLCJlcnJvciIsInJlc3BvbnNlIiwiZGF0YSIsImhhbmRsZUxpa2UiLCJpZCIsInVwZGF0ZSIsIm1hcCIsImIiLCJjdXJyZW50SWQiLCJfaWQiLCJoYW5kbGVEZWxldGUiLCJyZW1vdmUiLCJmaWx0ZXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsInNvcnRlZEJsb2dzIiwic29ydCIsImEiLCJsaWtlcyIsImJsb2ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcclxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcclxuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlJ1xyXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXHJcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xyXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXHJcblxyXG5jb25zdCBBcHAgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcclxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUoeyBtZXNzYWdlOiBudWxsLCB0eXBlOiBudWxsIH0pXHJcblxyXG4gIGNvbnN0IGJsb2dGb3JtUmVmID0gdXNlUmVmKG51bGwpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKChibG9ncykgPT4gc2V0QmxvZ3MoYmxvZ3MpKVxyXG4gIH0sIFtdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJylcclxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xyXG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxyXG4gICAgfVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBub3RpZnkgPSAobWVzc2FnZSwgdHlwZSA9ICdzdWNjZXNzJykgPT4ge1xyXG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSwgdHlwZSB9KVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6IG51bGwsIHR5cGU6IG51bGwgfSlcclxuICAgIH0sIDUwMDApXHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7IHVzZXJuYW1lLCBwYXNzd29yZCB9KVxyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcikpXHJcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXHJcbiAgICAgIHNldFVzZXIodXNlcilcclxuICAgICAgc2V0VXNlcm5hbWUoJycpXHJcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxyXG4gICAgICBub3RpZnkoYFdlbGNvbWUgJHt1c2VyLm5hbWUgfHwgdXNlci51c2VybmFtZX1gKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIG5vdGlmeSgnd3JvbmcgdXNlcm5hbWUgb3IgcGFzc3dvcmQnLCAnZXJyb3InKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXHJcbiAgICBibG9nU2VydmljZS5zZXRUb2tlbihudWxsKVxyXG4gICAgc2V0VXNlcihudWxsKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBTYWZlIGNoZWNrIGZvciByZWYgZXhlY3V0aW9uXHJcbiAgICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQ/LnRvZ2dsZVZpc2liaWxpdHkoKVxyXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHsgLi4ucmV0dXJuZWRCbG9nLCB1c2VyOiB1c2VyIH0pKVxyXG4gICAgICBub3RpZnkoYGEgbmV3IGJsb2cgJHtyZXR1cm5lZEJsb2cudGl0bGV9IGJ5ICR7cmV0dXJuZWRCbG9nLmF1dGhvcn0gYWRkZWRgKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0NyZWF0ZSBlcnJvcjonLCBleGNlcHRpb24ucmVzcG9uc2U/LmRhdGEgfHwgZXhjZXB0aW9uLm1lc3NhZ2UpXHJcbiAgICAgIG5vdGlmeSgnZmFpbGVkIHRvIGNyZWF0ZSBibG9nJywgJ2Vycm9yJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoaWQsIGJsb2dPYmplY3QpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJldHVybmVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShpZCwgYmxvZ09iamVjdClcclxuICAgICAgc2V0QmxvZ3MoXHJcbiAgICAgICAgYmxvZ3MubWFwKChiKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBjdXJyZW50SWQgPSBiLmlkIHx8IGIuX2lkXHJcbiAgICAgICAgICByZXR1cm4gY3VycmVudElkID09PSBpZFxyXG4gICAgICAgICAgICA/IHsgLi4ucmV0dXJuZWRCbG9nLCB1c2VyOiBiLnVzZXIgfHwgcmV0dXJuZWRCbG9nLnVzZXIgfVxyXG4gICAgICAgICAgICA6IGJcclxuICAgICAgICB9KVxyXG4gICAgICApXHJcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcclxuICAgICAgbm90aWZ5KCdlcnJvciB1cGRhdGluZyBsaWtlcycsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnJlbW92ZShpZClcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKChiKSA9PiAoYi5pZCB8fCBiLl9pZCkgIT09IGlkKSlcclxuICAgICAgbm90aWZ5KCdibG9nIHBvc3QgZGVsZXRlZCBzdWNjZXNzZnVsbHknKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0RlbGV0ZSBlcnJvciBkZXRhaWxzOicsIGV4Y2VwdGlvbi5yZXNwb25zZT8uZGF0YSB8fCBleGNlcHRpb24ubWVzc2FnZSlcclxuICAgICAgbm90aWZ5KCdmYWlsZWQgdG8gZGVsZXRlIGJsb2cgcG9zdCcsICdlcnJvcicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpZiAodXNlciA9PT0gbnVsbCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cclxuICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgdXNlcm5hbWVcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgcGFzc3dvcmRcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5sb2dpbjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjb25zdCBzb3J0ZWRCbG9ncyA9IFsuLi5ibG9nc10uc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+YmxvZ3M8L2gyPlxyXG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuICAgICAgPHA+XHJcbiAgICAgICAge3VzZXIubmFtZSB8fCB1c2VyLnVzZXJuYW1lfSBsb2dnZWQgaW57JyAnfVxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cclxuICAgICAgPC9wPlxyXG5cclxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cImNyZWF0ZSBuZXcgYmxvZ1wiIHJlZj17YmxvZ0Zvcm1SZWZ9PlxyXG4gICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxyXG4gICAgICA8L1RvZ2dsYWJsZT5cclxuXHJcbiAgICAgIHtzb3J0ZWRCbG9ncy5tYXAoKGJsb2cpID0+IChcclxuICAgICAgICA8QmxvZ1xyXG4gICAgICAgICAga2V5PXtibG9nLmlkIHx8IGJsb2cuX2lkfVxyXG4gICAgICAgICAgYmxvZz17YmxvZ31cclxuICAgICAgICAgIHVwZGF0ZUxpa2VzPXtoYW5kbGVMaWtlfVxyXG4gICAgICAgICAgZGVsZXRlQmxvZz17aGFuZGxlRGVsZXRlfVxyXG4gICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiQzovVXNlcnMvTUlDUk9TUEFDRS9EZXNrdG9wL3NvZnRuZXQvZnVsbHN0YWNrb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9