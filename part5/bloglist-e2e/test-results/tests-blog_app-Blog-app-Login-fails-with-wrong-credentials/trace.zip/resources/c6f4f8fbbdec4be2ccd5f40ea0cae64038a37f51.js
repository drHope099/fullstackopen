import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3814b24e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3814b24e"; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({ blog, updateLikes, deleteBlog, currentUser }) => {
  _s();
  const [visible, setVisible] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const removeButtonStyle = {
    backgroundColor: "#5594f2",
    color: "white",
    border: "none",
    borderRadius: 3,
    padding: "2px 6px",
    cursor: "pointer",
    marginTop: 4
  };
  const handleLike = () => {
    const userId = blog.user ? blog.user.id || blog.user : null;
    const updatedBlog = {
      user: userId,
      likes: (blog.likes || 0) + 1,
      author: blog.author,
      title: blog.title,
      url: blog.url
    };
    updateLikes(blog.id, updatedBlog);
  };
  const handleDelete = () => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}?`)) {
      deleteBlog(blog.id);
    }
  };
  const showDeleteButton = !blog.user || blog.user.username && currentUser?.username && blog.user.username === currentUser.username || blog.user.id && currentUser?.id && blog.user.id === currentUser.id || typeof blog.user === "string" && blog.user === currentUser?.id;
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setVisible(!visible), children: visible ? "hide" : "view" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 72,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    visible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: blog.url }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 78,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "likes ",
        blog.likes || 0,
        " ",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "like" }, void 0, false, {
          fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 81,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 79,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: blog.user?.name || blog.user?.username || "" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 83,
        columnNumber: 11
      }, this),
      showDeleteButton && /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: handleDelete, style: removeButtonStyle, children: "remove" }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 86,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 85,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/MICROSPACE/Desktop/softnet/fullstackopen/part5/bloglist-frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsT0FBT0EsQ0FBQyxFQUFFQyxNQUFNQyxhQUFhQyxZQUFZQyxZQUFZLE1BQU07QUFBQUMsS0FBQTtBQUMvRCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVIsU0FBUyxLQUFLO0FBRTVDLFFBQU1TLFlBQVk7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCQyxpQkFBaUI7QUFBQSxJQUNqQkMsT0FBTztBQUFBLElBQ1BMLFFBQVE7QUFBQSxJQUNSTSxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsRUFDYjtBQUVBLFFBQU1DLGFBQWFBLE1BQU07QUFDdkIsVUFBTUMsU0FBU3JCLEtBQUtzQixPQUFRdEIsS0FBS3NCLEtBQUtDLE1BQU12QixLQUFLc0IsT0FBUTtBQUN6RCxVQUFNRSxjQUFjO0FBQUEsTUFDbEJGLE1BQU1EO0FBQUFBLE1BQ05JLFFBQVF6QixLQUFLeUIsU0FBUyxLQUFLO0FBQUEsTUFDM0JDLFFBQVExQixLQUFLMEI7QUFBQUEsTUFDYkMsT0FBTzNCLEtBQUsyQjtBQUFBQSxNQUNaQyxLQUFLNUIsS0FBSzRCO0FBQUFBLElBQ1o7QUFDQTNCLGdCQUFZRCxLQUFLdUIsSUFBSUMsV0FBVztBQUFBLEVBQ2xDO0FBRUEsUUFBTUssZUFBZUEsTUFBTTtBQUN6QixRQUFJQyxPQUFPQyxRQUFRLGVBQWUvQixLQUFLMkIsS0FBSyxPQUFPM0IsS0FBSzBCLE1BQU0sR0FBRyxHQUFHO0FBQ2xFeEIsaUJBQVdGLEtBQUt1QixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0EsUUFBTVMsbUJBQ0osQ0FBQ2hDLEtBQUtzQixRQUNMdEIsS0FBS3NCLEtBQUtXLFlBQVk5QixhQUFhOEIsWUFBWWpDLEtBQUtzQixLQUFLVyxhQUFhOUIsWUFBWThCLFlBQ2xGakMsS0FBS3NCLEtBQUtDLE1BQU1wQixhQUFhb0IsTUFBTXZCLEtBQUtzQixLQUFLQyxPQUFPcEIsWUFBWW9CLE1BQ2hFLE9BQU92QixLQUFLc0IsU0FBUyxZQUFZdEIsS0FBS3NCLFNBQVNuQixhQUFhb0I7QUFFL0QsU0FDRSx1QkFBQyxTQUFJLE9BQU9oQixXQUNWO0FBQUEsMkJBQUMsU0FDRVA7QUFBQUEsV0FBSzJCO0FBQUFBLE1BQU07QUFBQSxNQUFFM0IsS0FBSzBCO0FBQUFBLE1BQVE7QUFBQSxNQUMzQix1QkFBQyxZQUFPLFNBQVMsTUFBTXBCLFdBQVcsQ0FBQ0QsT0FBTyxHQUN2Q0Esb0JBQVUsU0FBUyxVQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0NBLFdBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUtMLGVBQUs0QixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsU0FBSTtBQUFBO0FBQUEsUUFDSTVCLEtBQUt5QixTQUFTO0FBQUEsUUFBRztBQUFBLFFBQ3hCLHVCQUFDLFlBQU8sU0FBU0wsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBS3BCLGVBQUtzQixNQUFNWSxRQUFRbEMsS0FBS3NCLE1BQU1XLFlBQVksTUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQ2xERCxvQkFDQyx1QkFBQyxTQUNDLGlDQUFDLFlBQU8sU0FBU0gsY0FBYyxPQUFPaEIsbUJBQW1CLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLE9BdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDVCxHQXpFS0wsTUFBSTtBQUFBb0MsS0FBSnBDO0FBMkVOLGVBQWVBO0FBQUksSUFBQW9DO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJsb2ciLCJibG9nIiwidXBkYXRlTGlrZXMiLCJkZWxldGVCbG9nIiwiY3VycmVudFVzZXIiLCJfcyIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwiYmxvZ1N0eWxlIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0IiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJyZW1vdmVCdXR0b25TdHlsZSIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImN1cnNvciIsIm1hcmdpblRvcCIsImhhbmRsZUxpa2UiLCJ1c2VySWQiLCJ1c2VyIiwiaWQiLCJ1cGRhdGVkQmxvZyIsImxpa2VzIiwiYXV0aG9yIiwidGl0bGUiLCJ1cmwiLCJoYW5kbGVEZWxldGUiLCJ3aW5kb3ciLCJjb25maXJtIiwic2hvd0RlbGV0ZUJ1dHRvbiIsInVzZXJuYW1lIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBCbG9nID0gKHsgYmxvZywgdXBkYXRlTGlrZXMsIGRlbGV0ZUJsb2csIGN1cnJlbnRVc2VyIH0pID0+IHtcclxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xyXG4gICAgcGFkZGluZ1RvcDogMTAsXHJcbiAgICBwYWRkaW5nTGVmdDogMixcclxuICAgIGJvcmRlcjogJ3NvbGlkJyxcclxuICAgIGJvcmRlcldpZHRoOiAxLFxyXG4gICAgbWFyZ2luQm90dG9tOiA1LFxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVtb3ZlQnV0dG9uU3R5bGUgPSB7XHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjNTU5NGYyJyxcclxuICAgIGNvbG9yOiAnd2hpdGUnLFxyXG4gICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICBib3JkZXJSYWRpdXM6IDMsXHJcbiAgICBwYWRkaW5nOiAnMnB4IDZweCcsXHJcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcclxuICAgIG1hcmdpblRvcDogNCxcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSAoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VySWQgPSBibG9nLnVzZXIgPyAoYmxvZy51c2VyLmlkIHx8IGJsb2cudXNlcikgOiBudWxsXHJcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IHtcclxuICAgICAgdXNlcjogdXNlcklkLFxyXG4gICAgICBsaWtlczogKGJsb2cubGlrZXMgfHwgMCkgKyAxLFxyXG4gICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxyXG4gICAgICB0aXRsZTogYmxvZy50aXRsZSxcclxuICAgICAgdXJsOiBibG9nLnVybCxcclxuICAgIH1cclxuICAgIHVwZGF0ZUxpa2VzKGJsb2cuaWQsIHVwZGF0ZWRCbG9nKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gKCkgPT4ge1xyXG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZW1vdmUgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9P2ApKSB7XHJcbiAgICAgIGRlbGV0ZUJsb2coYmxvZy5pZClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIENoZWNrIHdoZXRoZXIgY3VycmVudCB1c2VyIGNyZWF0ZWQgdGhpcyBibG9nIHBvc3RcclxuICBjb25zdCBzaG93RGVsZXRlQnV0dG9uID1cclxuICAgICFibG9nLnVzZXIgfHxcclxuICAgIChibG9nLnVzZXIudXNlcm5hbWUgJiYgY3VycmVudFVzZXI/LnVzZXJuYW1lICYmIGJsb2cudXNlci51c2VybmFtZSA9PT0gY3VycmVudFVzZXIudXNlcm5hbWUpIHx8XHJcbiAgICAoYmxvZy51c2VyLmlkICYmIGN1cnJlbnRVc2VyPy5pZCAmJiBibG9nLnVzZXIuaWQgPT09IGN1cnJlbnRVc2VyLmlkKSB8fFxyXG4gICAgKHR5cGVvZiBibG9nLnVzZXIgPT09ICdzdHJpbmcnICYmIGJsb2cudXNlciA9PT0gY3VycmVudFVzZXI/LmlkKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17YmxvZ1N0eWxlfT5cclxuICAgICAgPGRpdj5cclxuICAgICAgICB7YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfXsnICd9XHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRWaXNpYmxlKCF2aXNpYmxlKX0+XHJcbiAgICAgICAgICB7dmlzaWJsZSA/ICdoaWRlJyA6ICd2aWV3J31cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHt2aXNpYmxlICYmIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdj57YmxvZy51cmx9PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICBsaWtlcyB7YmxvZy5saWtlcyB8fCAwfXsnICd9XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTGlrZX0+bGlrZTwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PntibG9nLnVzZXI/Lm5hbWUgfHwgYmxvZy51c2VyPy51c2VybmFtZSB8fCAnJ308L2Rpdj5cclxuICAgICAgICAgIHtzaG93RGVsZXRlQnV0dG9uICYmIChcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZURlbGV0ZX0gc3R5bGU9e3JlbW92ZUJ1dHRvblN0eWxlfT5cclxuICAgICAgICAgICAgICAgIHJlbW92ZVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6IkM6L1VzZXJzL01JQ1JPU1BBQ0UvRGVza3RvcC9zb2Z0bmV0L2Z1bGxzdGFja29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==